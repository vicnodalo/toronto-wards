WARD_WGS84_readme
 

Column name  (Description)
======================================
AREA_ID = AREA_ID
AREA_TYPE = AREA_TYPE
AREA_S_CD = AREA_SHORT_CODE
AREA_L_CD = AREA_LONG_CODE
AREA_NAME = AREA_NAME
X = X  (Easting, in MTM NAD 27(3 degree) Projection
)
Y = Y  (Northing, in MTM NAD 27(3 degree) Projection
)
LONGITUDE = LONGITUDE  (Longitude in WGS84 Coordinate System
)
LATITUDE = LATITUDE  (Latitude in WGS84 Coordinate System
)
